package calculo;

public class Person {

	private String name;
	private String user;
	private String sex;
	private int age;
	private int weight;
	private int height;
	private double imc;
	
	
	public Person(String name, String user, String sex, String age, String weight, String height) {
		this.setName(name);
		this.setUser(user);
		this.setSex(sex);
		this.setAge(Integer.parseInt(age));
		this.setWeight(Integer.parseInt(weight));
		this.setHeight(Integer.parseInt(height));
	}
	
	public void hacerIMC() {
		double res =(double) this.getWeight()/((this.getHeight() * this.getHeight()) / 100);
		this.setImc(res * 10);
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setUser(String user) {
		this.user = user;
	}
	
	public String getUser() {
		return user;
	}
	
	public void setSex(String sex) {
		this.sex = sex;
	}
	
	public String getSex() {
		return sex;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	public int getWeight() {
		return weight;
	}
	
	public void setHeight(int height) {
		this.height = height;
	}
	
	public int getHeight() {
		return height;
	}
	
	public void setImc(double imc) {
		this.imc = imc;
	}
	
	public double getImc() {
		return imc;
	}
	
}
