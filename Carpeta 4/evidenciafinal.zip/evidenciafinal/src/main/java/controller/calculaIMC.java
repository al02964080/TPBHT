package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import calculo.Person;

/**
 * Servlet implementation class calculaIMC
 */
@WebServlet(name = "/calculaIMC", urlPatterns = {"/calculaIMC"})
public class calculaIMC extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public calculaIMC() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("text/html;charset=UTF-8");
    	String name = request.getParameter("name");
		String user = request.getParameter("user");
		String sex = request.getParameter("sex");
		String age = request.getParameter("age");
		String weight = request.getParameter("weight");
		String height = request.getParameter("height");
		
		Person p = new Person(name, user, sex, age, weight, height);
		p.hacerIMC();
		Cookie ck = new Cookie("name", p.getName()+"");
		response.addCookie(ck);
		ck = new Cookie("user", p.getUser()+"");
		response.addCookie(ck);
		ck = new Cookie("weight", p.getWeight()+"");
		response.addCookie(ck);
		ck = new Cookie("height", p.getHeight()+"");
		response.addCookie(ck);
		ck = new Cookie("sex", p.getSex()+"");
		response.addCookie(ck);
		ck = new Cookie("age", p.getAge()+"");
		response.addCookie(ck);
		ck = new Cookie("imc", p.getImc()+"");
		response.addCookie(ck);
		
		
		request.setAttribute("person", p);
		request.getRequestDispatcher("/details.jsp").forward(request, response);
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request, response);
	}

}
