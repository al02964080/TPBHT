package calculo;

public class Triangulo {
	
	private int base;
	private int altura;
	private int area;
	private int perimetro;
	
	
	public Triangulo(String b, String a) {
		this.setBase(Integer.parseInt(b));
		this.setAltura(Integer.parseInt(a));
	}
	
	public void hacerArea() {
		int res = (this.getBase() * this.getAltura()) / 2;
		this.setArea(res);
	}
	
	public void hacerPerimetro() {
		int res = this.getBase() * 3;
		this.setPerimetro(res);
	}
	
	public void setBase(int b) {
		this.base = b;
	}
	
	public int getBase() {
		return base;
	}
	
	public void setAltura(int a) {
		this.altura = a;
	}
	
	public int getAltura() {
		return altura;
	}
	
	public void setArea(int res) {
		this.area = res;
	}
	
	public int getArea() {
		return area;
	}
	
	public void setPerimetro(int res) {
		this.perimetro = res;
	}
	
	public int getPerimetro() {
		return perimetro;
	}
	
	

}

